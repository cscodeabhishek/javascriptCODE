<?php 
  session_start();
  include "includes/header.php"; 
  //echo $_SESSION['user_verified'];
  if(isset($_SESSION['user_verified']) && $_SESSION['user_verified']==true){
    include "views/mainpage.php"; 
  }else{
      include "views/loginpage.php"; 
  }
  include "includes/footer.php"; 
?>
