<?php
session_start();
$timeout = 2592000;
ini_set("session.gc_maxlifetime", $timeout);
ini_set("session.cookie_lifetime", $timeout);

$s_name = session_name();
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $email = $_POST["email"];
    $enteredOTP = $_POST["otp"];
    $storedOTP = isset($_SESSION["otp"]) ? $_SESSION["otp"] : null;
    // var_dump(time() - $_SESSION['timestamp']);
    // exit();
    if (isset($_SESSION['timestamp']) && time() - $_SESSION['timestamp'] > 2592000) {
        session_unset();
        session_destroy();
        $response = '{"verified":false,"message":"Session Expired."}';
        exit();
    } else {
        $_SESSION['timestamp'] = time();

        if ($storedOTP && $enteredOTP == $storedOTP) {
            $curl = curl_init();
            curl_setopt_array($curl, [
                CURLOPT_URL => 'https://apps.designcan.in/kapture_db/store-logs',
                CURLOPT_RETURNTRANSFER => true,
                CURLOPT_ENCODING => '',
                CURLOPT_MAXREDIRS => 10,
                CURLOPT_TIMEOUT => 0,
                CURLOPT_FOLLOWLOCATION => true,
                CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
                CURLOPT_CUSTOMREQUEST => 'POST',
                CURLOPT_POSTFIELDS => [
                    'email' => $email,
                    'pageUrl' => 'kap-microsite/kapture-website',
                    'source' => 'kapture-website',
                ],
            ]);

            $response = curl_exec($curl);
            curl_close($curl);
            $result['status'] = "success";
            $result['message'] = "OTP Matched";
            $_SESSION['user_verified'] = true;
            $_SESSION['email'] = $email;
            echo json_encode($result);
        } else {
            $result['status'] = "failed";
            $result['message'] = "Invalid OTP";
            // $_SESSION['user_verified']=false;
            echo json_encode($result);
        }
    }
} else {
    $result['status'] = "failed";
    $result['message'] = "Invalid request method";
    $_SESSION['user_verified'] = false;
    echo json_encode($result);
}
?>
