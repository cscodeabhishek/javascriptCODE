<?php session_start();?>
<?php include "../includes/header.php"; 

if(isset($_SESSION['user_verified']) && $_SESSION['user_verified'] == true){
?>
<div id="l-sec"></div>
<div>
    <div class="banner">
        <div>
            <h1>Explore Demo Accounts: Access All Links Here</h1>
            <p>Experience our services firsthand with our demo accounts. Access all demo links conveniently from this page and discover the possibilities</p>
        </div>
        <div>
            <img class="banner-img" src="<?php echo BASE_URL;?>/assets/img/banner.png" alt="rect-img c" />
        </div>
    </div>
</div>
<div class="bc-parent">
    <div class="bc-child">Category</div>
</div>
<div class="container">
    <a href="<?php echo BASE_URL;?>/views/ecommerce.php" class="category-box">
        <img src="<?php echo BASE_URL;?>/assets/img/shopingcart.png" alt="shopping_cart" />
        <h6>E-Commerce</h6>
        <p>Access all demo account links and platform access for ticket submissions, making your experience seamless and efficient.</p>
    </a>
    <a href="javascript:void(0);" class="category-box no-border">
        <div class="wip">
            <img src="<?php echo BASE_URL;?>/assets/img/travel.png" alt="travel"  class="opc"/>
            <p class="wip-p">WIP</p>
        </div>
        <h6 class="opc">Travel</h6>
        <p class="opc">Explore and access all related links for a comprehensive experience. From booking to itinerary management, all at your fingertips</p>
    </a>
    <a href="<?php echo BASE_URL;?>/views/insurance.php" class="category-box">
        <img src="<?php echo BASE_URL;?>/assets/img/insurance.png" alt="insurance" />
        <h6>Insurance</h6>
        <p>Access all links related to policies, claims processing, and more, for a hands-on understanding of our offerings.</p>
    </a>
    <a href="javascript:void(0);" class="category-box no-border">
        <div class="wip">
            <img src="<?php echo BASE_URL;?>/assets/img/banking.png" alt="m-img" class="opc" />
            <p class="wip-p">WIP</p>
       </div>
        <h6 class="opc">Banking</h6>
        <p class="opc">Access all links for account management, transactions, and customer support, all in one place for your convenience</p>
    </a>
    <a href="javascript:void(0);" class="category-box no-border">
        <div class="wip">
            <img src="<?php echo BASE_URL;?>/assets/img/shopp.png" alt="shop_svg"  class="opc"/>
            <p class="wip-p">WIP</p>
       </div>
        <h6 class="opc">Consumer Durables</h6>
        <p class="opc">Explore a curated selection of durable goods, including electronics, appliances, and more, to enhance your everyday life and home experience.</p>
    </a>
    <a href="javascript:void(0);" class="category-box no-border">
        <div class="wip">
            <img src="<?php echo BASE_URL;?>/assets/img/energy.png" alt="wind_power" class="opc" />
            <p class="wip-p">WIP</p>
        </div>
        <h6 class="opc">Energy</h6>
        <p class="opc">Access all links related to energy plans and support services, empowering you to manage everything at a place.</p>
    </a>
</div>
<div class="emp-container">
    <div class="category-box">
        <img src="<?php echo BASE_URL;?>/assets/img/empex.png" alt="groups_svg"/>
        <h6>Employee Experience</h6>
        <p>Experience our employee experience demo account! Here, you'll find all the links you need to create tickets, access platforms, and more. Explore and discover the ease of managing your requests and tasks.</p>
        <div class="parent-div">
            <div class="child-div-three">
                <a href="https://demo.kapture.chat/" target="_blank" style="color: #539fe5; text-decoration: none;"> <span>URL:</span> https://demo.kapture.chat/</a>
            </div>
            <div  class="child-div-three"><span style="color: #ef374d;">Username: </span> &nbsp; chatdemo</div>
            <div class="child-div-three"><span style="color: #ef374d;">Password: </span> &nbsp; test</div>
        </div>
    </div>
</div>
<?php }
 include "../includes/footer.php"; ?>

