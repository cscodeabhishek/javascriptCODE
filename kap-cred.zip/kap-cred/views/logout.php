
<?php
session_unset();
session_destroy();

?>
<h2><a href="<?php echo BASE_URL ?>">back to login</a></h2>
</body>
</html>
