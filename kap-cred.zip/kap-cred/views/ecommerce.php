<?php include "../includes/header.php"; ?>
<div class="bc-parent-cat">
    <div class="bc-child-cat">
     <a href="<?php echo BASE_URL ?>">Home ></a>
     <span> ecommerce</span>
    </div>
</div>
<div class="accordion">
    <div class="accordion-item">
        <input type="checkbox" id="accordion1" checked />
        <label for="accordion1" class="accordion-item-title"><span class="icon"></span>Login Credentials (Admin)</label>
        <div class="accordion-item-desc">
            <p class="para-description">Use the following login credentials (URL, username and password) to access the demo account. Explore the features and functionalities available to get a feel for the full experience.</p>
            <div class="parent-div">
                <div class="child-div-three">
                    <a href=" https://democrm.kapturecrm.com/nui_develop/democrm/login" target="_blank"><span>URL:</span> &nbsp;demo.kapturecrm.com/nui/</a>
                </div>
                <div class="child-div-three"><span>Username:</span> &nbsp; democrm</div>
                <div class="child-div-three"><span>Password: </span> &nbsp;Democrm@123</div>
            </div>
        </div>
    </div>
    <div class="accordion-item">
        <input type="checkbox" id="accordion2" />
        <label for="accordion2" class="accordion-item-title"><span class="icon"></span>Login Credentials (Other Employees)</label>
        <div class="accordion-item-desc">
            <p class="para-description">Use the following login credentials (URL, username and password) to access the demo account. Explore the features and functionalities available to get a feel for the full experience.</p>
            <div class="parent-div">
                <div class="child-div-four">
                    <p><span>Queue:</span> &nbsp; NA</p>
                </div>
                <div class="child-div-four">
                    <p><span>Name:</span> &nbsp; AARAV KAPOOR</p>
                </div>
                <div class="child-div-four">
                    <p><span>Username:</span> &nbsp; aaravkapoor</p>
                </div>
                <div class="child-div-four">
                    <p><span>Password:</span> &nbsp; Kapture123</p>
                </div>
            </div>
            <div class="parent-div">
                <div class="child-div-four">
                    <p><span>Queue:</span> &nbsp; NA</p>
                </div>
                <div class="child-div-four">
                    <p><span>Name:</span> &nbsp; DIVYA M</p>
                </div>
                <div class="child-div-four">
                    <p><span>Username:</span> &nbsp; divyam</p>
                </div>
                <div class="child-div-four">
                    <p><span>Password:</span> &nbsp; Kapture123</p>
                </div>
            </div>
            <div class="parent-div">
                <div class="child-div-four">
                    <p><span>Queue:</span> &nbsp; Email, Call</p>
                </div>
                <div class="child-div-four">
                    <p><span>Name:</span> &nbsp; ROHAN SHAH</p>
                </div>
                <div class="child-div-four">
                    <p><span>Username:</span> &nbsp; rohanshah</p>
                </div>
                <div class="child-div-four">
                    <p><span>Password:</span> &nbsp; Kapture123</p>
                </div>
            </div>
            <div class="parent-div">
                <div class="child-div-four">
                    <p><span>Queue:</span> &nbsp; WhatsApp</p>
                </div>
                <div class="child-div-four">
                    <p><span>Name:</span> &nbsp; SOURAV KUMAR</p>
                </div>
                <div class="child-div-four">
                    <p><span>Username:</span> &nbsp; souravkumar</p>
                </div>
                <div class="child-div-four">
                    <p><span>Password:</span> &nbsp; Kapture123</p>
                </div>
            </div>
            <div class="parent-div">
                <div class="child-div-four">
                    <p><span>Queue:</span> &nbsp; Facebook</p>
                </div>
                <div class="child-div-four">
                    <p><span>Name:</span> &nbsp; ANJALI SHARMA</p>
                </div>
                <div class="child-div-four">
                    <p><span>Username:</span> &nbsp; anjalisharma</p>
                </div>
                <div class="child-div-four">
                    <p><span>Password:</span> &nbsp; Kapture123</p>
                </div>
            </div>
            <div class="parent-div">
                <div class="child-div-four">
                    <p><span>Queue:</span> &nbsp; Instagram</p>
                </div>
                <div class="child-div-four">
                    <p><span>Name:</span> &nbsp; POOJA DAS</p>
                </div>
                <div class="child-div-four">
                    <p><span>Username:</span> &nbsp; poojadas</p>
                </div>
                <div class="child-div-four">
                    <p><span>Password:</span> &nbsp;  Kapture123</p>
                </div>
            </div>
            <div class="parent-div">
                <div class="child-div-four">
                    <p><span>Queue:</span> &nbsp; Chat</p>
                </div>
                <div class="child-div-four">
                    <p><span>Name:</span> &nbsp; MANISHA MALHOTRA</p>
                </div>
                <div class="child-div-four">
                    <p><span>Username:</span> &nbsp; manishamalhotra</p>
                </div>
                <div class="child-div-four">
                    <p><span>Password:</span> &nbsp; Kapture123</p>
                </div>
            </div>
            <div class="parent-div">
                <div class="child-div-four">
                    <p><span>Queue:</span> &nbsp; LinkedIn</p>
                </div>
                <div class="child-div-four">
                    <p><span>Name:</span> &nbsp; ASHISH MEHTA</p>
                </div>
                <div class="child-div-four">
                    <p><span>Username:</span> &nbsp; ashishmehta</p>
                </div>
                <div class="child-div-four">
                    <p><span>Password:</span> &nbsp; Kapture123</p>
                </div>
            </div>
            <div class="parent-div">
                <div class="child-div-four">
                    <p><span>Queue:</span> &nbsp; Twitter</p>
                </div>
                <div class="child-div-four">
                    <p><span>Name:</span> &nbsp; KAMAL KHAN</p>
                </div>
                <div class="child-div-four">
                    <p><span>Username:</span> &nbsp; kamalkhan</p>
                </div>
                <div class="child-div-four">
                    <p><span>Password:</span> &nbsp; Kapture123</p>
                </div>
            </div>
        </div>
    </div>
    <div class="accordion-item">
        <input type="checkbox" id="accordion3" />
        <label for="accordion3" class="accordion-item-title"><span class="icon"></span>Self-Serve</label>
        <div class="accordion-item-desc">
            <h2 class="heading">Shopper's Bazaar</h2>
            <p class="para-description">
                This website offers a comprehensive customer service experience. Access all FAQs, raise queries, and track the status of your requests effortlessly. View and manage all your orders conveniently in one place. Our AI chatbot
                is available to assist you with any issues regarding your orders or the platform. Additionally, streamline your communication with us using pre-defined messages through Kapture CX for quick and efficient interactions.
            </p>
            <p class="note">Note:  <span class="para-description">Login to your own account by entering your email and password.</span></p>
            <div class="parent-div">
                <div class="child-div-one">
                    <a href="https://india-shoppersbazaar.designcan.in/login.php" target="_blank"><span>URL:</span> https://india-shoppersbazaar.designcan.in/login.php</a>
                </div>
            </div>
            <h2 class="heading">Selfserve Widget</h2>
            <p class="para-description">
                Explore our self-serve options for convenient ticket management. View and track all your raised tickets, as well as create new ones as needed. Access a comprehensive FAQ section covering all aspects of your insurance
                policies for quick answers to your queries.
            </p>
            <div class="parent-div">
                <div class="child-div-half">
                    <a href="https://india-shoppersbazaar.designcan.in/" target="_blank"><span>URL:</span> https://india-shoppersbazaar.designcan.in/</a>
                </div>
                <div class="child-div-half">
                        <span>How to access:</span>
                        <div class="self-serve-btn"> 
                            <p>You can access the self serve widget by clicking on the button on the bottom right hand side.</p>
                            <button class="need-help-btn">Need help?</button>
                        </div>
                </div>
            </div>
            <h2 class="heading">Selfserve Portal</h2>
            <p class="para-description">
                This portal provides easy access to all integrated FAQs, allowing you to quickly find answers to common queries. You can browse through the FAQs to see what information has been added or updated. The system is designed to
                make it convenient for you to stay informed and resolve any doubts you may have.
            </p>
            <div class="parent-div">
                <div class="child-div-one">
                    <a href="https://democrm.kapturecrm.com/selfserve/views/cx/config.php" target="_blank"><span>URL:</span> https://democrm.kapturecrm.com/selfserve/views/cx/config.php</a>
                </div>
            </div>
            <h2 class="heading">Selfserve Mobile Apps</h2>
            <p class="para-description">
                Access our self-serve features on our mobile apps, available for both Android and iOS platforms. Manage your account, raise tickets, and access FAQs conveniently on the go. Download our app now to experience seamless
                insurance management at your fingertips
            </p>
            <div class="parent-div">
                <div class="child-div-half">
                    <a href="https://play.google.com/store/apps/details?id=com.kapturecrm.KapSupport" target="_blank"><span> Google PlayStore URL:</span>https://play.google.com/store/apps/details?id=com.kapturecrm.KapSupport</a>
                </div>
                <div class="child-div-half">
                    <a href="https://apps.apple.com/in/app/kapture-support/id6475958653" target="_blank"><span> Apple AppStore URL:</span>https://apps.apple.com/in/app/kapture-support/id6475958653</a>
                </div>
            </div>
        </div>
    </div>
    <div class="accordion-item">
        <input type="checkbox" id="accordion4" />
        <label for="accordion4" class="accordion-item-title"><span class="icon"></span>Social Media Integrations</label>
        <div class="accordion-item-desc">
            <p class="para-description">
                Seamlessly connect with Kapture CX through WhatsApp, Facebook, email, and other platforms. Raise tickets, share feedback, and interact with us effortlessly. Enhance your customer experience with our integrated social media
                functionalities
            </p>
            <div class="parent-div">
                <div class="child-div-half-social">
                    <img src="<?php echo BASE_URL ?>/assets/img/email.png" />
                    <a href="mailto:support.isb@kapturedesk.com">support.isb@kapturedesk.com</a>
                </div>
                <div class="child-div-half-social">
                    <img src="<?php echo BASE_URL ?>/assets/img/call.png" />
                    <a href="tel:080-46107210">080-46107210</a>
                </div>
            </div>
            <div class="parent-div">
                <div class="child-div-half-social">
                    <img src="<?php echo BASE_URL ?>/assets/img/whatsapp.png" />
                    <a href="tel:+12532426690">+12532426690</a>
                </div>
                <div class="child-div-half-social">
                    <img src="<?php echo BASE_URL ?>/assets/img/twitter.png" />
                    <a href="https://twitter.com/kapturedemo/with_replies" target="_blank">https://twitter.com/kapturedemo/with_replies</a>
                </div>
            </div>
            <div class="parent-div">
                <div class="child-div-half-social">
                    <img src="<?php echo BASE_URL ?>/assets/img/Vector.png" />
                    <a href="https://www.linkedin.com/company/kapturedemo/" target="_blank">https://www.linkedin.com/company/kapturedemo/</a>
                </div>
                <div class="child-div-half-social">
                    <img src="<?php echo BASE_URL ?>/assets/img/socialfb.png" />
                    <a href="https://www.facebook.com/kapdemo/" target="_blank">https://www.facebook.com/kapdemo/</a>
                </div>
            </div>
            <div class="parent-div">
                <div class="child-div-half-social">
                    <img src="<?php echo BASE_URL ?>/assets/img/youtube.png" />
                    <a href="https://www.youtube.com/@kapturecrm9082" target="_blank">https://www.youtube.com/@kapturecrm9082</a>
                </div>
                <div class="child-div-half-social">
                    <img src="<?php echo BASE_URL ?>/assets/img/instagram.png" />
                    <a href="https://www.instagram.com/direct/t/17848125428720600/?__coig_login=1" target="_blank">https://www.instagram.com/direct/t/17848125428720600/?__coig_login=1</a>
                </div>
            </div>
        </div>
    </div>
    <div class="accordion-item">
        <input type="checkbox" id="accordion5" />
        <label for="accordion5" class="accordion-item-title"><span class="icon"></span>Gen AI</label>
        <div class="accordion-item-desc">
            <h2 class="heading">Gen AI</h2>
            <p class="para-description">
                The Gen AI Knowledge Base offers a variety of options for integration with the Gen AI chatbot on insurance website. Choose a module from the knowledge base to integrate with the chatbot, enhancing its capabilities.This
                integration allows the chatbot to provide more accurate and personalized responses to customer inquiries.
            </p>
            <p class="para-description">Please follow the steps below to access the Gen AI KB</p>
            <p class="note">Note: <span class="para-description">You can access by going to KMS -> Gen AI KB</span></p>
            <div class="parent-div">
                <div class="child-div-one">
                    <a href="https://democrm.kapturecrm.com/selfserve/logout.php" target="_blank"><span>URL:</span> https://democrm.kapturecrm.com/selfserve/logout.php</a>
                </div>
            </div>
            <h2 class="heading">Create KB Link</h2>
            <p class="para-description">Please follow the steps below to access the Gen AI KB</p>
            <p class="note">Note: <span class="para-description">You can access by going to KMS -> Gen AI KB -> Add Knowledge Base (+)</span></p>
            <div class="parent-div">
                <div class="child-div-one">
                    <a href="https://democrm.kapturecrm.com/selfserve/logout.php" target="_blank"><span>URL:</span> https://democrm.kapturecrm.com/selfserve/logout.php</a>
                </div>
            </div>
            <h2 class="heading">Select KB/Test it Out Option</h2>
            <p class="para-description">
                Choose the 'Select KB' option to pick a module that will be reflected in the website's AI chat. This feature allows you to customize the knowledge base content that the chatbot will use to respond to inquiries. Selecting the
                right module ensures that the chatbot provides accurate and relevant information to users.
            </p>
            <p class="method">Method 1</p>
            <p class="para-description">Please follow the steps below to select KB:</p>
            <p class="note">Note:  <span class="para-description">You can access by going to CX-Selfserve -> Config -> Surya Kant(edit) -> Module (left hand side panel) -> Gen AI FAQs (put the toggle on) -> Gen AI KB (select the option that you want to see in the E-commerce website link)</span></p>
            <p class="method">Method 2</p>
            <p class="para-description">Please follow the steps below to select KB:</p>
            <p class="note">Note: <span class="para-description">You can access by going to KMS -> Try it out (any one of the KB that you would want the chat config to reflect on the E-commerce website)</span></p>
            <div class="parent-div">
                <div class="child-div-one">
                    <a href="https://democrm.kapturecrm.com/selfserve/logout.php" target="_blank"><span>URL:</span>https://democrm.kapturecrm.com/selfserve/logout.php </a>
                </div>
            </div>
            <h2 class="heading">Chat Link (in Indian Shoppers Bazar Link)</h2>
            <p class="para-description">
                Access our self-serve features on our mobile apps, available for both Android and iOS platforms. Manage your account, raise tickets, and access FAQs conveniently on the go. Download our app now to experience seamless
                insurance management at your fingertips
            </p>
            <div class="parent-div">
                <div class="child-div-half">
                    <a href="https://india-shoppersbazaar.designcan.in/" target="_blank"><span>URL:</span> https://india-shoppersbazaar.designcan.in/</a>
                </div>
                <div class="child-div-half">
                        <span>How to access:</span>
                        <div class="self-serve-btn"> 
                            <p>You can access the self serve widget by clicking on the button on the bottom right hand side.</p>
                            <button class="gen-ai-btn">Gen AI?</button>
                        </div>
                </div>
            </div>
        </div>
    </div>
    <div class="accordion-item">
        <input type="checkbox" id="accordion6" />
        <label for="accordion6" class="accordion-item-title"><span class="icon"></span>Sales Flow Documentation</label>
        <div class="accordion-item-desc">
            <p class="para-description">
                In this Sales Flow document, you'll find comprehensive information about our team members, account details, current queues, and folders. Explore the document to understand the structure and organization of our demo insurance
                account. If you have any questions or need further clarification, this document serves as a valuable resource to help you navigate the demo account efficiently.
            </p>
            <div class="parent-div">
                <div class="child-div-one">
                    <a href="https://docs.google.com/document/d/11yeTJfxXfaj8EUFkP_ztqoqqUG-kyiWEeeKu229PRsA/edit" target="_blank">
                        <span>URL:</span> &nbsp; https://docs.google.com/document/d/11yeTJfxXfaj8EUFkP_ztqoqqUG-kyiWEeeKu229PRsA/edit
                    </a>
                </div>
            </div>
        </div>
    </div>
</div>
<?php include "../includes/footer.php"; ?>
