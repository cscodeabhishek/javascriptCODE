<?php session_start(); ?>
<div id="l-sec"></div>
<div class="login-ui-container">
    <div class="login-img">
        <img src="<?php echo BASE_URL ?>/assets/img/pc.svg" />
    </div>
    <div class="login-container-form">
        <form id="email_form" method="post" action="javascript:void(0);" onsubmit="generateOTP()">
            <img class="avator" src="<?php echo BASE_URL ?>/assets/img/avator.svg">
            <h2>Log in</h2>
            <div class="input-div">
                <div class="i">
                    <i class="fas fa-user"></i>
                </div>
                <div class="input-wrapper">
                    <input class="input" type="text" name="useremail"  id="useremail" placeholder="Enter your email" value="" />
                </div>
            </div>
            <input type="submit" class="btn" value="Get OTP"  />
        </form>
        <form class="otp-form" id="OTP_form" method="post" action="javascript:void(0);" onsubmit="validateOTP()">
            <img class="avator" src="<?php echo BASE_URL ?>/assets/img/avator.svg" />
            <h2>Log in</h2>
            <div class="input-div">
                <div class="i">
                    <i class="fas fa-user"></i>
                </div>
                <div class="input-wrapper">
                    <input class="input" type="text" id="userOtp" name="userOtp" placeholder="Enter OTP" value="" />
                </div>
            </div>
            <input type="submit" class="btn" value="Submit" />
        </form>
    </div>
</div>

