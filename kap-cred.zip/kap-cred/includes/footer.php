<div  class="kap-footer">
        <img src="<?php echo BASE_URL ?>/assets/img/footerimgg.png">
        <p class="footer-p">© 2024 Kapture CX. All rights reserved.</p>
</div>
<script src="<?php echo BASE_URL ?>/assets/js/script.js"></script>

</body>
</html>