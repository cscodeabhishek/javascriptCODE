function toggleFaq(faqId) {
    var faqItem = document.getElementById(faqId);
    var faqContent = faqItem.querySelector(".accordion-content");

    // Close all other FAQ items
    var allFaqItems = document.querySelectorAll(".accordion-item");
    allFaqItems.forEach(function (item) {
        if (item.id !== faqId) {
            item.setAttribute("aria-expanded", "false");
            item.classList.remove("open-faq");
            item.querySelector(".accordion-content").style.maxHeight = "0";
        }
    });
    // Toggle the clicked FAQ item
    var isExpanded = faqItem.getAttribute("aria-expanded") === "true";
    faqItem.setAttribute("aria-expanded", isExpanded ? "false" : "true");
    faqItem.classList.toggle("open-faq", !isExpanded);

    // Handle the transition
    faqContent.style.maxHeight = isExpanded ? "0" : faqContent.scrollHeight + "px";
}

document.addEventListener("DOMContentLoaded", function () {
    var checkboxes = document.querySelectorAll('.accordion-item input[type="checkbox"]');
    checkboxes.forEach(function (checkbox) {
        checkbox.addEventListener("change", function () {
            checkboxes.forEach(function (otherCheckbox) {
                if (otherCheckbox !== checkbox) {
                    otherCheckbox.checked = false;
                }
            });
        });
    });
});

// js for login and verify otp
const inputs = document.querySelectorAll(".input");
let currentForm = "email_form";
let email;

document.getElementById("email_form").style.display = currentForm === "email_form" ? "block" : "none";
document.getElementById("OTP_form").style.display = currentForm === "OTP_form" ? "block" : "none";


function toggleForms() {
    document.getElementById("email_form").style.display = currentForm === "email_form" ? "none" : "block";
    document.getElementById("OTP_form").style.display = currentForm === "OTP_form" ? "none" : "block";

    currentForm = currentForm === "email_form" ? "OTP_form" : "email_form";
}


function generateOTP() {
    $("#l-sec").show();
    var form = $("#email_form")[0];
    var data = new FormData(form);
    $.ajax({
        url: baseurl + "/controller/logincontroller.php",
        enctype: "multipart/form-data",
        processData: false,
        contentType: false,
        cache: false,
        data: data,
        type: "POST",
        success: function (result) {
            toggleForms();
            $("#l-sec").hide();
        },
    });
}

function validateOTP() {
    var data = new FormData();
    const emailInput = document.querySelector('#email_form input[name="useremail"]');
    var email = emailInput.value;
    const otpInput = document.querySelector('#OTP_form input[name="userOtp"]');
    const otp = otpInput.value;
    data.append('email', email);
    data.append('otp', otp);
    $("#l-sec").show();
    $.ajax({
        url: baseurl + "/controller/otpcontroller.php",
        processData: false,
        contentType: false,
        cache: false,
        data: data,
        type: "POST",
        success: function (result) {
            var data = JSON.parse(result);
            if (data.status == "success") {
                $("#l-sec").hide();
                window.location.href = baseurl;
            } else {
                alert(data.message);
                window.location.href = baseurl + "/views/loginpage.php";
            }
        },
    });
}
